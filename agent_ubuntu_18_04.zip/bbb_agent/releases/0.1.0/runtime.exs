import Config


config :bbb_agent, BbbAgent.MyConfig,
  is_player: System.get_env("IS_PLAYER") == "true",
  send_to_player_time: System.get_env("SEND_TO_PLAYER_TIME") |> String.to_integer(),
  player_presentation_folder: System.get_env("PLAYER_RESENTATION_FOLDER"),
  player_name: System.get_env("PLAYER_NAME"),
  api_base_url:  System.get_env("API_BASE_URL") ,
  api_user_name: System.get_env("API_USER_NAME"),
  api_user_pw: System.get_env("API_USER_PW"),
  server_to_send_file: System.get_env("SERVER_TO_SEND_FILE") ,
  send_to_player_time: System.get_env("SEND_TO_PLAYER_TIME") |> String.to_integer(),
  worker_presentation_folder: System.get_env("WORKER_PRESENTAION_FOLDER")
